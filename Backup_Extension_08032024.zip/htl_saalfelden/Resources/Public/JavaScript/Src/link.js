var item;

function SetIcon(){
    item = new Image();
    if('btn-default'){
     item.src = "../Icons/arrow-right.svg"
    }
}
