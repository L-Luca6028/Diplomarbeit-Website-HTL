<?php

/**
 * Extension Manager/Repository config file for ext "htl_saalfelden".
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'HTL Saalfelden',
    'description' => '',
    'category' => 'templates',
    'constraints' => [
        'depends' => [
            'bootstrap_package' => '13.0.0-14.9.99',
        ],
        'conflicts' => [
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'HtlSaalfelden\\HtlSaalfelden\\' => 'Classes',
        ],
    ],
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'RAI',
    'author_email' => 'RAI@RAI.com',
    'author_company' => 'HTL Saalfelden',
    'version' => '1.0.0',
];
