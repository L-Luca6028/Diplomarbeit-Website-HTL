CKEDITOR.plugins.setLang(
    'bootstrappackage_address',
    'en',
    {
        toolbar: 'Insert Address'
    }
);
