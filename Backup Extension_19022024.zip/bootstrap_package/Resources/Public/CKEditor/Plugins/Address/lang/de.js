CKEDITOR.plugins.setLang(
    'bootstrappackage_address',
    'de',
    {
        toolbar: 'Adresse einfügen'
    }
);
