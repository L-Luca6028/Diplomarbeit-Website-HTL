﻿.. include:: /Includes.rst.txt

.. _configuration:

=============
Configuration
=============

**Table of Contents:**

.. toctree::
   :maxdepth: 2
   :titlesonly:

   Extension/Index
   ImageRendering/Index
   TypoScript/Index
