 // Funktion zum Laden verschiedener Inhalte basierend auf der Bildschirmgröße
 function loadContent() {
    if (window.innerWidth < 768) { // Beispiel-Grenzwert für kleinere Bildschirme
        // Laden der HTML-Datei für kleinere Bildschirme (z.B. mit einem Accordion)
        document.getElementById('texticonelem').innerHTML = '<object type="text/html" data="../Texticon.html" width="100%" height="100%"></object>';
    }
}

// Initialer Aufruf der Funktion beim Laden der Seite und bei Größenänderungen des Bildschirms
window.onload = loadContent;
window.onresize = loadContent;