﻿.. include:: /Includes.rst.txt

.. _admin-manual:

Administrator manual
====================

This chapter describes how to manage the extension from a superuser point of
view.

For a complete changelog please see the release notes on
`GitHub <https://github.com/benjaminkott/bootstrap_package/releases/>`_.

**Table of Contents:**

.. toctree::
   :maxdepth: 1
   :titlesonly:

   Migration/6-2-14
   Migration/6-2-11
