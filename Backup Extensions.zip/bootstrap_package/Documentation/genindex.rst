.. include:: /Includes.rst.txt

=====
Index
=====

.. Sphinx will insert here the general index automatically.
