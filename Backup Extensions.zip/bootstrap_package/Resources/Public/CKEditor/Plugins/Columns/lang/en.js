CKEDITOR.plugins.setLang(
    'bootstrappackage_columns',
    'en',
    {
        toolbar: 'Insert columns'
    }
);
