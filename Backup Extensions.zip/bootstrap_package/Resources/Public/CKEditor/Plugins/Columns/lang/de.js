CKEDITOR.plugins.setLang(
    'bootstrappackage_columns',
    'de',
    {
        toolbar: 'Spalten einfügen'
    }
);
