CKEDITOR.plugins.setLang(
    'bootstrappackage_indent',
    'de',
    {
        toolbar: 'Text einrücken'
    }
);
