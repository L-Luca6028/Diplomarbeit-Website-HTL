CKEDITOR.plugins.setLang(
    'bootstrappackage_indent',
    'en',
    {
        toolbar: 'Indent text'
    }
);
